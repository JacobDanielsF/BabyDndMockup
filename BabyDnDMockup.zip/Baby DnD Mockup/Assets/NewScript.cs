﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NewScript : MonoBehaviour
{
    public Button CalculateButton;
    public Text ResultText;
    public GameObject Greybox1;
    public GameObject Greybox2;

    public InputField D20RollInput1;
    public InputField D20RollInput2;
    public InputField specifiedRollInput;
    public Dropdown advantageDropdown;
    public Toggle savingThrowToggle;
    public Toggle abilityForDamageToggle;
    public Toggle healToggle;
    public Toggle autoRollToggle;
    public InputField xRollInput;
    public InputField yRollInput;

    public InputField NameInput;
    public InputField HPInput;
    public InputField ArmorInput;
    public InputField ModifierInput;
    public InputField HitBonusInput;
    public InputField ProficiencyInput;
    public Button NewEntityButton;
    public Dropdown attackDropdown;
    public Dropdown targetDropdown;

    public Entity attackEntity;
    public Entity targetEntity;

    public Dictionary<string, Entity> entityDictionary = new Dictionary<string, Entity>();

    public bool usingAdvantage = false;
    public bool advantage = true;
    public int D20Roll1 = 1;
    public int D20Roll2 = 1;
    public int specifiedRoll = 1;
    public bool savingThrow = false;
    public bool abilityForDamage = true;
    public float result = 0;
    public bool crit = false;
    public bool heal = false;
    public bool autoRoll = false;
    public int xRoll = 2;
    public int yRoll = 4;


    // Start is called before the first frame update
    void Start()
    {
        CalculateButton.onClick.AddListener(Calculate);
        NewEntityButton.onClick.AddListener(MakeEntity);

        ResultText.text = "";

        D20RollInput1.onValueChanged.AddListener(delegate { UpdateValues(); });
        D20RollInput2.onValueChanged.AddListener(delegate { UpdateValues(); });
        specifiedRollInput.onValueChanged.AddListener(delegate { UpdateValues(); });
        advantageDropdown.onValueChanged.AddListener(delegate { UpdateValues(); });
        savingThrowToggle.onValueChanged.AddListener(delegate { UpdateValues(); });
        abilityForDamageToggle.onValueChanged.AddListener(delegate { UpdateValues(); });
        healToggle.onValueChanged.AddListener(delegate { UpdateValues(); });
        autoRollToggle.onValueChanged.AddListener(delegate { UpdateValues(); });
        xRollInput.onValueChanged.AddListener(delegate { UpdateValues(); });
        yRollInput.onValueChanged.AddListener(delegate { UpdateValues(); });

        attackDropdown.onValueChanged.AddListener(delegate { UpdateEntities(); });
        targetDropdown.onValueChanged.AddListener(delegate { UpdateEntities(); });
    }

    void MakeEntity()
    {
        Entity newEntity = new Entity();

        string name = NameInput.text;
        newEntity.name = name;
        newEntity.maxHealth = int.Parse(HPInput.text);
        newEntity.health = int.Parse(HPInput.text);
        newEntity.armorClass = int.Parse(ArmorInput.text);
        newEntity.attackHitBonus = int.Parse(HitBonusInput.text);
        newEntity.proficiency = int.Parse(ProficiencyInput.text);

        entityDictionary.Add(NameInput.text, newEntity);

        List<string> options = new List<string>();
        options.Add(name);
        attackDropdown.AddOptions(options);
        targetDropdown.AddOptions(options);
    }

    void UpdateEntities()
    {
        if (attackDropdown.options[attackDropdown.value].text != "N/A")
        {
            attackEntity = entityDictionary[attackDropdown.options[attackDropdown.value].text];
        }
        
        if (targetDropdown.options[targetDropdown.value].text != "N/A")
        {
            targetEntity = entityDictionary[targetDropdown.options[targetDropdown.value].text];
        }
    }

    void UpdateValues()
    {
        if (D20RollInput1.text != "")
        {
            D20Roll1 = int.Parse(D20RollInput1.text);
        }
        
        if (D20RollInput2.text != "")
        {
            D20Roll2 = int.Parse(D20RollInput2.text);
        }
        

        if (advantageDropdown.value == 0)
        {
            usingAdvantage = false;
        }
        else
        {
            usingAdvantage = true;

            if (advantageDropdown.value == 1)
            {
                advantage = true;
            }
            else
            {
                advantage = false;
            }
        }

        savingThrow = savingThrowToggle.isOn;
        abilityForDamage = abilityForDamageToggle.isOn;
        heal = healToggle.isOn;
        autoRoll = autoRollToggle.isOn;

        if (autoRoll)
        {
            Greybox1.SetActive(true);
            Greybox2.SetActive(false);
        }
        else
        {
            Greybox1.SetActive(false);
            Greybox2.SetActive(true);
        }

        if (xRollInput.text != "")
        {
            xRoll = int.Parse(xRollInput.text);
        }

        if (yRollInput.text != "")
        {
            yRoll = int.Parse(yRollInput.text);
        }
    }

    void Calculate()
    {
        if (attackDropdown.options[attackDropdown.value].text != "N/A" && targetDropdown.options[targetDropdown.value].text != "N/A")
        {
            result = 0;
            crit = false;

            Step1();
        }
    }
    
    void Step1()
    {
        bool miss = false;

        if (!savingThrow)
        {
            int roll = 0;

            if (!autoRoll)
            {
                if (!usingAdvantage)
                {
                    roll = D20Roll1;
                }
                else if (advantage)
                {
                    roll = Mathf.Min(D20Roll1, D20Roll2);
                }
                else
                {
                    roll = Mathf.Max(D20Roll1, D20Roll2);
                }
            }
            else
            {
                if (!usingAdvantage)
                {
                    roll = Random.Range(1, 20);
                }
                else if (advantage)
                {
                    int rand1 = Random.Range(1, 20 + 1);
                    int rand2 = Random.Range(1, 20 + 1);
                    roll = Mathf.Min(D20Roll1, D20Roll2);
                }
                else
                {
                    int rand1 = Random.Range(1, 20 + 1);
                    int rand2 = Random.Range(1, 20 + 1);
                    roll = Mathf.Max(D20Roll1, D20Roll2);
                }
            }

            if (roll + attackEntity.attackHitBonus < targetEntity.armorClass)
            {
                miss = true; // miss
                ResultText.text = "Miss! Target armor class too high.";
            }

            if (!miss)
            {
                if (roll == 1)
                {
                    miss = true; // miss
                    ResultText.text = "Miss! Rolled a 1.";
                }
                else if (roll == 20)
                {
                    crit = true;
                }
            }

            if (!miss)
            {
                Step2();
            }
        }
        else
        {
            if (D20Roll1 + targetEntity.abilityModifier < 8 + attackEntity.proficiency + attackEntity.abilityModifier)
            {
                miss = true;
                ResultText.text = "Miss! Saving throw failed.";
            }

            if (!miss)
            {
                Step2();
            }
        }
    }

    void Step2()
    {
        int damage = 0;

        if (!autoRoll)
        {
            damage = specifiedRoll;
        }
        else
        {
            for (int i = 0; i < xRoll; i++)
            {
                damage += Random.Range(1, yRoll + 1);
            }
        }

        if (abilityForDamage)
        {
            damage += attackEntity.abilityModifier;
        }

        if (crit)
        {
            damage *= 2;
        }

        if (heal)
        {
            damage *= -1;
        }

        targetEntity.health = Mathf.Clamp(targetEntity.health - damage, 0, targetEntity.maxHealth);

        result = damage;

        string newText = "";

        if (crit)
        {
            newText += "Critical Hit! ";
        }

        if (!heal)
        {
            if (damage != 0)
            {
                newText += attackEntity.name + " dealt " + damage + " damage to " + targetEntity.name + ". ";
            }
            else
            {
                newText += "There was no effect...";
            }
        }
        else
        {
            if (damage != 0)
            {
                newText += targetEntity.name + " recovered " + (damage * -1) + " health. ";
            }
            else
            {
                newText += "There was no effect...";
            }
        }

        if (targetEntity.health == 0)
        {
            newText += targetEntity.name + " died.";
        }

        ResultText.text = newText;
    }

    [System.Serializable]
    public class Entity
    {
        public string name;

        public int maxHealth;
        public int health;
        public int armorClass;
        public int abilityModifier;
        public int attackHitBonus;
        public int proficiency;
    }
}
